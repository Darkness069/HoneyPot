module Network_pb
class Honeypot_pb
	
require "socket"
require "gtk3"

def initialize()

builder_file = "#{File.expand_path(File.dirname(__FILE__))}/HoneyPot.ui"
builder = Gtk::Builder.new(:file => builder_file)

window = builder.get_object("window")
window.signal_connect("destroy") { Gtk.main_quit }

button1 = builder.get_object("button1")
button1.signal_connect("clicked") {agarravalor()}

radioButton1 = builder.get_object("radiobutton1")
radioButton1.signal_connect("toggled"){automatic_config()}

radioButton2 = builder.get_object("radiobutton2")
radioButton2.signal_connect("toggled"){manual_config()}

$text1 = builder.get_object("textbuffer1")
$text2 = builder.get_object("textbuffer2")
$text3 = builder.get_object("textbuffer3")
$combo1 = builder.get_object("combo1")
$combo2 = builder.get_object("combo2")

def automatic_config()
	$text1.set_text("80")
	$text2.set_text("<HEAD>\n<TITLE>Access denied</TITLE>\n</HEAD>\n<H2>Access denied</H2>\n" + "<H3>HTTP Referrer login failed</H3>\n" + "<H3>IP Address login failed</H3>\n" + "<P>\n#{Time.now.to_s}\n</P>")
	$combo1.set_active_id(0.to_s)
	$combo2.set_active_id(0.to_s)
end
def manual_config()
	$text1.set_text("")
	$text2.set_text("")
	$combo1.set_active_id(0.to_s)
	$combo2.set_active_id(0.to_s)
end
def agarravalor()
	port = $text1.get_text($text1.start_iter, $text1.end_iter,false).to_i
	message = $text2.get_text($text2.start_iter, $text2.end_iter,true)
	sound = $combo1.active_text()
	log = $combo2.active_text()
	logname = "#{File.dirname(__FILE__)}/../../other/log_honeypot.txt"
	honeyconfig(port,message,sound,log,logname)
end
def honeyconfig(port, message, sound, log, logname) # Function to launch the Honeypot.
	begin
		tcpserver = TCPServer.new("", port)
		if tcpserver
			puts ""
			puts "  HONEYPOT ACTIVADO EN EL  PUERTO #{port} (#{Time.now.to_s})"
			puts ""
			if log == "Si" || log == "SI"
				# If log is enabled, writes Honeypot activation time.
				begin
					File.open(logname, "a") do |logf|
						logf.puts "#################### Honeypot log"
						logf.puts ""
						logf.puts "  HONEYPOT ACTIVADO EN EL  PUERTO #{port} (#{Time.now.to_s})"
						logf.puts ""
					end
				rescue Errno::ENOENT
					puts ""
					puts " Saving log error: No such file or directory."
					puts ""
				end
			end
			loop do
				socket = tcpserver.accept
				sleep(1) # It is to solve possible DoS Attacks.
				if socket
					Thread.new do
						remotePort, remoteIp = Socket.unpack_sockaddr_in(socket.getpeername) # Gets the remote port and ip.
						puts ""
						puts "  INTENTO DE INTRUSIÓN DETECTADO! desde #{remoteIp}:#{remotePort} (#{Time.now.to_s})"
						puts " -----------------------------"
						reciv = socket.recv(1000).to_s
						puts reciv
						if sound == "Si" || sound == "SI"
							# If sound is enabled, then beep 3 times.
							puts "\a\a\a"
						end
						if log == "Si" || log == "SI"
							# If log is enabled, writes the intrusion.
							begin
								File.open(logname, "a") do |logf|
									logf.puts ""
									logf.puts "  INTENTO DE INTRUSIÓN DETECTADO! desde #{remoteIp}:#{remotePort} (#{Time.now.to_s})"
									logf.puts " -----------------------------"
									logf.puts reciv
								end
							rescue Errno::ENOENT
								puts ""
								puts " Saving log error: No such file or directory."
								puts ""
							end
						end
						sleep(2) # This is a sticky honeypot.
						socket.write(message)
						socket.close
					end
				end
			end
		end
	rescue Errno::EACCES
		puts ""
		puts " Error: Honeypot requiere privilegios de root."
		puts ""
	rescue Errno::EADDRINUSE
		puts ""
		puts " Error: Puerto en uso."
		puts ""
	rescue
		puts ""
		puts " Error desconocido."
		puts ""
	end
end
puts ""
title "// Honeypot //"
puts ""
warning "Deberias ejecutar Honeypot con privilegios de root.\n"
Gtk.main()
end
end
end
