
$pb_log_enabled = false
$pb_log_file = File.dirname(__FILE__) + "/other/log/pentbox_log_" + ENV['USER'] + ".log"

$protected_mode = true

$text_color = true

dir = File.dirname(__FILE__)
require dir + "/lib/pb_proced_lib.rb" # Common procedures and functions.

version = "1.5"
Signal.trap("INT") do
	puts ""
	puts "[*] Saliendo ..."
	puts ""
	pb_write_log("exiting", "Core")
	exit
end
#####

pb_write_log("honeypot loaded", "Core")

srand(Time.now.to_i)
banner = rand(3)

puts ""
title " Honey-Pot #{version} "

case banner
	when 0
		puts "                                     .::!!!!!!!:. "
		puts "  .!!!!!:.                        .:!!!!!!!!!!!! "
		puts "  ~~~~!!!!!!.                 .:!!!!!!!!!UWWW$$$ "
		puts "      :$$NWX!!:           .:!!!!!!XUWW$$$$$$$$$P "
		puts "      $$$$$##WX!:      .<!!!!UW$$$$   $$$$$$$$# "
		puts "      $$$$$  $$$UX   :!!UW$$$$$$$$$   4$$$$$* "    
		puts "      ^$$$B  $$$$      $$$$$$$$$$$$   d$$R* "
		puts "        **$bd$$$$      '*$$$$$$$$$$$o+#  "
		puts "             ****          ******* "          
	when 1
		puts "         __"
		puts "        U00U|.'@@@@@@`."
		puts "        |__|(@@@@@@@@@@)"
		puts "             (@@@@@@@@)"
		puts "             `YY~~~~YY'"
		puts "              ||    ||"
	when 2
		puts "             .__."
		puts "             (oo)____"
		puts "             (__)    )--*"
		puts "                ||--|| "
end

sleep(0.25)
	option1 = "1"
	case option1
		when "1"
			option2 = "1"
			case option2
				when "0"
					module_exec = false
				when "1"
					require "#{dir}/tools/network/honeypot.rb"
					Network_pb::Honeypot_pb.new()
			end		
	end
	if module_exec == true
		puts ""
		puts "[*] Module execution finished."
		puts ""
	end

